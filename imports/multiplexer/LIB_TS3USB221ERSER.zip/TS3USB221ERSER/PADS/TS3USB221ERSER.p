*PADS-LIBRARY-PART-TYPES-V9*

TS3USB221ERSER TS3USB221ERSER I ANA 9 1 0 0 0
TIMESTAMP 2026.08.01.01.14.05
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TS3USB221ERSER
"Mouser Part Number" 595-TS3USB221ERSER
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TS3USB221ERSER?qs=OaSNdy%2FNfzkaIRVJErYydw%3D%3D
"Arrow Part Number" TS3USB221ERSER
"Arrow Price/Stock" https://www.arrow.com/en/products/ts3usb221erser/texas-instruments.html?utm_currency=USD&region=nac
"Description" Texas Instruments TS3USB221ERSER, Analogue Switch Single:1 x 2 480MBps, 2.3  3.6 V, 10-Pin UQFN
"Datasheet Link" http://www.ti.com/lit/gpn/ts3usb221e
"Geometry.Height" 0mm
GATE 1 10 0
TS3USB221ERSER
1 0 U 1D+
2 0 U 1D-
3 0 U 2D+
4 0 U 2D-
5 0 U GND
6 0 U \OE
7 0 U D-
8 0 U D+
9 0 U S
10 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
418140/2125237/2.50/10/4/Integrated Circuit
